<?php $__env->startSection('title'); ?>Shop Page::MangoBD
<?php echo e(Session::put('page', 'shop')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
<?php echo $__env->make('front.includes.banner', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

<!-- page -->
<div class="services-breadcrumb">
    <div class="agile_inner_breadcrumb">
        <div class="container">
            <ul class="w3_short">
                <li>
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                    <i>|</i>
                </li>
                <li>Search Result Page</li>
            </ul>
        </div>
    </div>
</div>
<!-- //page -->

    <!-- top Products -->
    <div class="ads-grid">
        <div class="container">
            <!-- tittle heading -->
            <h3 class="tittle-w3l">Mango : <?php echo e($searchName); ?>

                <span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
            </h3>
            <!-- //tittle heading -->
            <!-- product left -->
            <div class="side-bar col-md-3">

                <div class="search-hotel">
                    <h3 class="agileits-sear-head">Search Here..</h3>
                    <form action="<?php echo e(url('/search-mango')); ?>" method="get">
                        <input value="<?php echo e(request()->input('query')); ?>" type="search" placeholder="Mango or Seller name..." name="search" required="">
                        <button style="height: 40px;" type="submit" class="btn btn-default" aria-label="Left Align">
                            <span class="fa fa-search" aria-hidden="true"> </span>
                        </button>
                    </form>
                </div>


                <!-- price range -->
                <form action="<?php echo e(url('/filter-products')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <!-- price range -->
                    <div class="range">
                        <h3 class="agileits-sear-head">Price range</h3>
                        <ul class="dropdown-menu6">
                            <li>
                                <div id="slider-range"></div>
                                <input type="text" name="priceRange" id="amount" style="border: 0; color: #ffffff; font-weight: normal;" />
                            </li>
                        </ul>
                    </div>
                    <!-- //price range -->
                    <!-- food preference -->
                    <div class="left-side">
                        <h3 class="agileits-sear-head">Mango | Type</h3>
                        <ul>
                            <li>
                                <input type="checkbox" name="mangoType" value="raw" class="checked">
                                <span class="span">Raw Mango</span>
                            </li>
                            <li>
                                <input type="checkbox" name="mangoType" value="ripe" class="checked">
                                <span class="span">Ripe Mango</span>
                            </li>
                        </ul>
                    </div>
                    <!-- //food preference -->
                    <!-- discounts -->
                    <div class="left-side">
                        <h3 class="agileits-sear-head">Discount</h3>
                        
                        <ul>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="1">
                                <span class="span">1% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="5">
                                <span class="span">5% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="10">
                                <span class="span">10% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="15">
                                <span class="span">15% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="20">
                                <span class="span">20% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="25">
                                <span class="span">25% or More</span>
                            </li>
                            <li>
                                <input name="productDiscount" type="checkbox" class="checked" value="30">
                                <span class="span">30% or More</span>
                            </li>
                        </ul>
                        <button type="submit" class="btn btn-success">Filter Now</button>
                    </div>
                </form>
                <!-- //discounts -->
                <!-- //discounts -->
              
               
            </div>
            <!-- //product left -->
            <!-- product right -->
            <div class="agileinfo-ads-display col-md-9">
                <div class="wrapper">
                    <!-- first section (nuts) -->
                    <div class="product-sec1">
                        <h3 class="heading-tittle">Mango</h3>
                        <?php if($products == ''): ?>
                            <h1>No Products Founds</h1>
                        <?php endif; ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 product-men">
                                <div class="men-pro-item simpleCart_shelfItem">
                                    <div class="men-thumb-item">
                                        <img src="<?php echo e($product->picture_1); ?>" alt="" style="height: 118px; width: 150px;">
                                        <div class="men-cart-pro">
                                            <div class="inner-men-cart-pro">
                                                <a href="<?php echo e(url('/products/'.$product->unique_id)); ?>" class="link-product-add-cart">Quick View</a>
                                            </div>
                                        </div>
                                        <span class="product-new-top">Fresh</span>
                                    </div>
                                    <div class="item-info-product ">
                                        <h4>
                                            <a href="<?php echo e(url('/products/'.$product->unique_id)); ?>"><?php echo e($product->name); ?>, <?php echo e($product->quantity); ?>kg</a>
                                        </h4>
                                        <div class="info-product-price">
                                            <span class="item_price"><?php echo e($product->sellPrice); ?>tk</span>
                                            <del><?php echo e($product->regPrice); ?>tk</del>
                                        </div>

                                        <div>
                                            <form action="<?php echo e(url('/add-to-cart')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="form-group">
                                                    <input type="hidden" name="qty" value="1" min="1">
                                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                </div>
                                                <div>
                                                    <input type="submit" name="btn" value="Add To Cart" class="my-cart-btn item_add button">
                                                </div>
                                            </form>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="clearfix"></div>
                    </div>
                    <!-- //first section (nuts) -->
                    <!-- second section (nuts special) -->
                    <!--<div class="product-sec1 product-sec2">
                            <div class="col-xs-7 effect-bg">
                                <h3 class="">Pure Energy</h3>
                                <h6>Enjoy our all healthy Fruits</h6>
                                <p>Get Extra 10% Off</p>
                            </div>
                            <h3 class="w3l-nut-middle">Mango</h3>
                            <div class="col-xs-1 effect-bg">

                            </div>
                            <div class="col-xs-4 bg-right-nut">
                                <img src="images/mangolitchi.jpg" alt="">
                            </div>
                            <div class="clearfix"></div>
                        </div>-->
                    <!-- //second section (nuts special) -->
                <!-- third section (oils)
					<div class="product-sec1">
						<h3 class="heading-tittle">Mango</h3>


                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 product-men">
                        <div class="men-pro-item simpleCart_shelfItem">
                            <div class="men-thumb-item">
                                <img src="<?php echo e($product->picture_1); ?>" alt="" style="height: 150px; width: 150px;">
                                        <div class="men-cart-pro">
                                            <div class="inner-men-cart-pro">
                                                <a href="<?php echo e(url('/products/'.$product->unique_id)); ?>" class="link-product-add-cart">Quick View</a>
                                            </div>
                                        </div>
                                        <span class="product-new-top">Fresh</span>
                                    </div>
                                    <div class="item-info-product ">
                                        <h4>
                                            <a href="<?php echo e(url('/products/'.$product->unique_id)); ?>"><?php echo e($product->name); ?>, <?php echo e($product->quantity); ?>kg</a>
                                        </h4>
                                        <div class="info-product-price">
                                            <span class="item_price"><?php echo e($product->sellPrice); ?>tk</span>
                                            <del><?php echo e($product->regPrice); ?>tk</del>
                                        </div>

                                        <div>
                                            <form action="<?php echo e(url('/add-to-cart')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <input type="hidden" name="qty" value="1" min="1">
                                <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                                </div>
                                                <div>
                                                    <input type="submit" name="btn" value="Add To Cart" class="my-cart-btn item_add button">
                                                </div>
                                            </form>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="clearfix"></div>
                    </div>
                    third section (oils) -->

                </div>
            </div>
            <!-- //product right -->
        </div>
    </div>
    <!-- //top products -->
    <!-- special offers -->
    <div class="featured-section" id="projects">
        <div class="container">
            <!-- tittle heading -->
            <h3 class="tittle-w3l">Most Selling Products
                <span class="heading-style">
					<i></i>
					<i></i>
					<i></i>
				</span>
            </h3>
            <!-- //tittle heading -->
            <div class="content-bottom-in">
                <ul id="flexiselDemo1">
                    <?php $__currentLoopData = $productsMostSells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productsMostSell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 product-men" >
                            <div class="men-pro-item simpleCart_shelfItem" style="height: 350px; width: 250px;">
                                <div class="men-thumb-item">
                                    <img src="<?php echo e($productsMostSell->picture_1); ?>" alt="" style="height: 150px; width: 200px;">
                                    <div class="men-cart-pro">
                                        <div class="inner-men-cart-pro">
                                            <a href="<?php echo e(url('/products/'.$productsMostSell->unique_id)); ?>" class="link-product-add-cart">Quick View</a>
                                        </div>
                                    </div>
                                    <span class="product-new-top">Fresh</span>
                                </div>
                                <div class="item-info-product ">
                                    <h4 style="margin-bottom: 5px;">
                                        <a href="<?php echo e(url('/products/'.$productsMostSell->unique_id)); ?>"><?php echo e($productsMostSell->name); ?>, <?php echo e($productsMostSell->quantity); ?>kg</a>
                                    </h4>
                                    <h4>
                                        <?php if($productsMostSell->discount < 1): ?>
                                            <a href="<?php echo e(url('/products/'.$productsMostSell->unique_id)); ?>" style="font-size: 14px; background-color: #ffffff; color: white; padding: 0 2px; border-radius: 2px;"></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('/products/'.$productsMostSell->unique_id)); ?>" style="font-size: 14px; background-color: #b2a50b; color: white; padding: 0 2px; border-radius: 2px;"><?php echo e($productsMostSell->discount); ?>% Discount</a>
                                        <?php endif; ?>
                                    </h4>
                                    <div class="info-product-price">
                                        <span class="item_price"><?php echo e($productsMostSell->sellPrice); ?>tk Per Kg</span>
                                        <del><?php echo e($productsMostSell->regPrice); ?>tk</del>
                                    </div>

                                    <div>
                                        <form action="<?php echo e(url('/add-to-cart')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-group">
                                                <input type="hidden" name="qty" value="1" min="1">
                                                <input type="hidden" name="id" value="<?php echo e($productsMostSell->id); ?>">
                                            </div>
                                            <div>
                                                <input type="submit" name="btn" value="Add To Cart" class="my-cart-btn item_add button">
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
    <!-- //special offers -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>