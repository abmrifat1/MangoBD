<?php $__env->startSection('content'); ?>
       



    <div style=" height: 800px; background: #23a2c9">
        <h1 style="color: white; text-align: center; padding-top: 400px;">Welcome MangoBD Admin Panel</h1>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>