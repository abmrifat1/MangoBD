<!doctype html>
<html>
<body>
<h2>Hi, <?php echo e($data['name']); ?></h2>
<p>Yo're just signup in The Mango BD shop, Please verify your email using the bellow code</p>
<h3><?php echo e($data['verification_code']); ?></h3>
</body>
</html>