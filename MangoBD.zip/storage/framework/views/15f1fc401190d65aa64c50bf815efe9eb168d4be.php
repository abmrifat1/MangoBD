

<!-- //Footer -->
<footer>
    <div class="container">
        <!-- footer first section -->
        <p class="footer-main" style="background: #eeeeee; text-align: center; padding: 10px;">
            <span style="text-align: center"></span> People like take fruits. Mango is one of them. Mango is one of the most popular fruit in our country. People want to take fresh mango but most of the time they don’t get best mango though pay much money. Now to overcome this problem we will make a mango based online shopping web application.  Through this site people can easily purchase best mango mango with legal price. MangoBD Ensure the pure fruit 100%.</p>
        <!-- //footer first section -->
        
        <!-- footer third section -->
        <div class="footer-info w3-agileits-info">
            <!-- footer categories -->
            <div class="col-sm-5 address-right">
                <div class="col-xs-6 footer-grids">
                    <h3>Categories</h3>
                    <ul>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(url('category-products/'.$category->unique_id)); ?>"><?php echo e($category->name); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="clearfix"></div>
            </div>
            <!-- //footer categories -->
            <!-- quick links -->
            <div class="col-sm-7 address-right">
                <div class="col-xs-6 footer-grids">
                    <h3>Quick Links</h3>
                    <ul>
                        <li>
                            <a href="<?php echo e(url('/shop')); ?>">Shop</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/about')); ?>">About Us</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/faqs')); ?>">Faqs</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/blog')); ?>">Blog</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/contact')); ?>">Contact Us</a>
                        </li>
                    </ul>
                </div>
                <div class="col-xs-6 footer-grids">
                    <h3>Get in Touch</h3>
                    <ul>
                        <li>
                            <i class="fa fa-map-marker"></i> Rajshahi, Bangladesh.</li>
                        <li>
                            <i class="fa fa-mobile"></i> +01777-822162 </li>
                        <li>
                            <i class="fa fa-phone"></i> +111 11 1111 </li>
                        <li>
                            <i class="fa fa-envelope-o"></i>
                            <a href="<?php echo e(url('/')); ?>"> themangobd.com</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- //quick links -->
            <!-- social icons -->
            
            <div class="clearfix"></div>
        </div>
        <!-- //footer third section -->
        <!-- footer fourth section (text) -->
        
            <!-- //brands -->
            <!-- payment -->
            <div class="sub-some child-momu">
                <h5>Payment Method</h5>
                <ul>
                    <li>
                        <img src="<?php echo e(asset('front/images/cash.jpg')); ?>" style="width: 50px; height: 50px;" alt="">
                    </li>
                    <li>
                        <img src="<?php echo e(asset('front/images/bkash.jpg')); ?>" style="width: 50px; height: 50px;" alt="">
                    </li>
                    
                </ul>
            </div>
            <!-- //payment -->
        </div>
        <!-- //footer fourth section (text) -->
    </div>
</footer>
<!-- //footer -->
<!-- copyright -->
<div class="copy-right">
    <div class="container">
        <p>© 2018 Best Online Shop For Fruits | Design by
            <a href="http://w3layouts.com"> Md Emamul Murshalin</a>
        </p>
    </div>
</div>
<!-- //copyright -->