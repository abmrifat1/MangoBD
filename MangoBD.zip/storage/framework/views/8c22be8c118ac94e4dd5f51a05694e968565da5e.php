<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Message Replay Form</h3>
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Message Information</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Settings 1</a>
                                    </li>
                                    <li><a href="#">Settings 2</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <?php echo Form::open(['url' => '/admin/contact/send','method'=>'POST','class'=>'form-horizontal form-label-left']); ?>

                        
                        <div class="item form-group">
                            <?php echo Form::label('name','Name *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('name',$messageContacts->name,['class'=>'form-control col-md-7 col-xs-12','id'=>'name','required'=>'required']); ?>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="item form-group">
                            <?php echo Form::label('email','To *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('email',$messageContacts->email,['class'=>'form-control col-md-7 col-xs-12','id'=>'email','required'=>'required']); ?>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('subject','Subject',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('subject',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'subject']); ?>

                                <?php if($errors->has('subject')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('subject')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="item form-group">
                            <?php echo Form::label('message','Message *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::textarea('message',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'subject','required'=>'required']); ?>

                                <?php if($errors->has('message')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('message')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="ln_solid"></div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <?php echo Form::submit('Send message',['class'=>'btn btn-success','id'=>'send']); ?>


                                
                            </div>
                        </div>
                        </form>
                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>