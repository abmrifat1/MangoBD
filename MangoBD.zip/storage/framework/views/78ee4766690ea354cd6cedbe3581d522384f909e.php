<?php $__env->startSection('form'); ?>
<div class="log-w3">
    <div class="w3layouts-main">
        <h2>Sign In Now</h2>
        <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="email" class="ggg" name="email" placeholder="E-MAIL" required="">
            <input type="password" class="ggg" name="password" placeholder="PASSWORD" required="">
            
            
            <div class="clearfix"></div>
            <div class="form-group">
                <input type="submit" value="Sign In" name="btn" class="btn btn-success btn-block">
            </div>

        </form>
        <p>Don't Have an Account ?<a href="<?php echo e(url('/register')); ?>">Create an account</a></p>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.login.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>