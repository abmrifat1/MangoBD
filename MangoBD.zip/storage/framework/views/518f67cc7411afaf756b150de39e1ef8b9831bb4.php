<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Product Information Form</h3>
            </div>
        </div>
        <div class="clearfix"></div>

        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Product Information</h2>
                        <a href="<?php echo e(url('/admin/product')); ?>"><h2 style="float: right; margin-left: 10px; padding: 7px; margin-bottom: 20px; border-radius: 6px;" class="btn-success">Display Product</h2></a>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#">Settings 1</a>
                                    </li>
                                    <li><a href="#">Settings 2</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <?php echo Form::open(['url' => 'admin/product','method'=>'POST','files' => true,'class'=>'form-horizontal form-label-left']); ?>



                        <div class="item form-group">
                            <?php echo Form::label('name','Product Name *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('name',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'name','required'=>'required']); ?>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        '""
                        <div class="item form-group">
                            <?php echo Form::label('sku','SKU *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('sku',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'sku','required'=>'required']); ?>

                                <?php if($errors->has('sku')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('sku')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('regPrice','Regular Price *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('regPrice',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'regPrice','required'=>'required']); ?>

                                <?php if($errors->has('regPrice')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('regPrice')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group" style="width: 80%; margin-left: 50px;">
                            <?php echo Form::label('discount','Discount *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::number('discount',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'discount','required'=>'required']); ?>

                                <?php if($errors->has('discount')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('discount')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div>
                            <p style="font-size: 28px; font-weight: bolder;">%</p>
                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('sellPrice','Sell Price *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::text('sellPrice',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'sellPrice','required'=>'required']); ?>

                                <?php if($errors->has('sellPrice')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('sellPrice')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('quantity','Quantity *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::number('quantity',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'quantity','required'=>'required']); ?>

                                <?php if($errors->has('quantity')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('quantity')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            
                            <?php echo Form::label('categoryId','Category ID ',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select name="usrId" id="" class="form-control">
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="item form-group">
                            
                            <?php echo Form::label('categoryId','Category ID ',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <select name="categoryId" id="" class="form-control">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="item form-group">
                            
                            <?php echo Form::label('isStock','Stock Status ',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::select('isStock', ['Stock' => 'Yes', 'Empty' => 'No'], 1, ['class'=>'form-control','id'=>'isStock']); ?>

                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('image','Image *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">

                                <?php echo Form::file('image',['accept'=>'image/*','class'=>'form-control col-md-7 col-xs-12','id'=>'image']); ?>


                                <?php echo Form::file('image1',['accept'=>'image/*','class'=>'form-control col-md-7 col-xs-12','id'=>'image1']); ?>


                                <?php echo Form::file('image2',['accept'=>'image/*','class'=>'form-control col-md-7 col-xs-12','id'=>'image2']); ?>


                                <span>Image will be 400x300</span>
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php elseif($errors->has('image1')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('image1')); ?></strong>
                                    </span>
                                <?php elseif($errors->has('image2')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('image2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            <?php echo Form::label('description','Description *',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::textarea('description',null,['class'=>'form-control col-md-7 col-xs-12','id'=>'description']); ?>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block error">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item form-group">
                            
                            <?php echo Form::label('type','Product Type ',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::select('type', ['Select Type', 'raw' => 'Raw', 'ripe' => 'Ripe'], 1, ['class'=>'form-control','id'=>'type']); ?>

                            </div>
                        </div>

                        <div class="item form-group">
                            
                            <?php echo Form::label('isApprove','Approve Status ',['class'=>'control-label col-md-3 col-sm-3 col-xs-12']); ?>

                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <?php echo Form::select('isApprove', ['Approve' => 'Yes', 'Not_Approved' => 'No'], 1, ['class'=>'form-control','id'=>'isApprove']); ?>

                            </div>
                        </div>


                        <div class="ln_solid"></div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <?php echo Form::submit('Submit',['class'=>'btn btn-success','id'=>'send']); ?>


                                
                            </div>
                        </div>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>