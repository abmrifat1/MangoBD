This website are building using PHP laravel freamwork, HTML5, CSS3, JavaScript, Jquery, Ajax, Bootstrap.

## About Project
This project for develop a Ecommerce multivendor website where vendor can register their account and canbe able to upload their product and then they will get payment when anyone buy something.
## About Laravel

Laravel is a web application framework with expressive, elegant syntax. We believe development must be an enjoyable and creative experience to be truly fulfilling. Laravel attempts to take the pain out of development by easing common tasks used in the majority of web projects, such as:

## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
